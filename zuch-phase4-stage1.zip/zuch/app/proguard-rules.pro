# Firestore model classes (added in later phases) must keep their fields
-keepclassmembers class com.zuch.app.data.model.** { *; }
