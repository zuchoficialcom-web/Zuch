package com.zuch.app.data

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

enum class ThemeMode { SYSTEM, LIGHT, DARK }

/** Tiny local settings store (theme now, language code later). */
object SettingsStore {
    private var prefs: SharedPreferences? = null
    private val _theme = MutableStateFlow(ThemeMode.SYSTEM)
    val theme: StateFlow<ThemeMode> = _theme

    fun init(context: Context) {
        val p = context.getSharedPreferences("zuch_settings", Context.MODE_PRIVATE)
        prefs = p
        _theme.value = runCatching { ThemeMode.valueOf(p.getString("theme", null) ?: "SYSTEM") }
            .getOrDefault(ThemeMode.SYSTEM)
    }

    fun setTheme(mode: ThemeMode) {
        _theme.value = mode
        prefs?.edit()?.putString("theme", mode.name)?.apply()
    }
}
