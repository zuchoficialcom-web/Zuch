package com.zuch.app.ui.main

import androidx.annotation.StringRes
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.zuch.app.R
import com.zuch.app.data.SettingsStore
import com.zuch.app.data.ThemeMode

/** Honest placeholder for screens that arrive in a later phase. */
@Composable
fun PhasePlaceholder(@StringRes titleRes: Int, phase: Int) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(stringResource(titleRes), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text(
                stringResource(R.string.coming_in_phase, phase),
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
fun SettingsScreen(email: String, onSignOut: () -> Unit) {
    val mode by SettingsStore.theme.collectAsStateWithLifecycle()

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        SectionTitle(R.string.settings_appearance)
        ThemeRow(R.string.theme_system, mode == ThemeMode.SYSTEM) { SettingsStore.setTheme(ThemeMode.SYSTEM) }
        ThemeRow(R.string.theme_light, mode == ThemeMode.LIGHT) { SettingsStore.setTheme(ThemeMode.LIGHT) }
        ThemeRow(R.string.theme_dark, mode == ThemeMode.DARK) { SettingsStore.setTheme(ThemeMode.DARK) }

        HorizontalDivider(Modifier.padding(vertical = 12.dp), color = MaterialTheme.colorScheme.outline)

        SectionTitle(R.string.settings_language)
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            RadioButton(selected = true, onClick = {})
            Text(stringResource(R.string.language_english))
        }
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            RadioButton(selected = false, onClick = {}, enabled = false)
            Column {
                Text(stringResource(R.string.language_community), color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(
                    stringResource(R.string.language_coming_later),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        HorizontalDivider(Modifier.padding(vertical = 12.dp), color = MaterialTheme.colorScheme.outline)

        SectionTitle(R.string.settings_account)
        Text(email, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(bottom = 8.dp))
        OutlinedButton(onClick = onSignOut) { Text(stringResource(R.string.sign_out)) }
    }
}

@Composable
private fun SectionTitle(@StringRes res: Int) {
    Text(
        stringResource(res),
        style = MaterialTheme.typography.titleSmall,
        color = MaterialTheme.colorScheme.secondary,
        fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(bottom = 4.dp)
    )
}

@Composable
private fun ThemeRow(@StringRes label: Int, selected: Boolean, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RadioButton(selected = selected, onClick = onClick)
        Text(stringResource(label))
    }
}
