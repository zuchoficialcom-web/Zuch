package com.zuch.app

import android.app.Application
import com.zuch.app.data.SettingsStore

class ZuchApp : Application() {
    override fun onCreate() {
        super.onCreate()
        SettingsStore.init(this)
    }
}
