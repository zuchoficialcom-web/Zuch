package com.zuch.app.ui.auth

import android.util.Patterns
import androidx.annotation.StringRes
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.firebase.FirebaseNetworkException
import com.google.firebase.auth.FirebaseAuthException
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException
import com.google.firebase.auth.FirebaseAuthInvalidUserException
import com.google.firebase.auth.FirebaseAuthUserCollisionException
import com.google.firebase.auth.FirebaseUser
import com.zuch.app.R
import com.zuch.app.data.auth.AuthRepository
import com.zuch.app.data.auth.UsernameTakenException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class AuthUiState(
    val loading: Boolean = false,
    @StringRes val error: Int? = null,
    @StringRes val info: Int? = null
)

class AuthViewModel(private val repo: AuthRepository = AuthRepository()) : ViewModel() {

    val user: StateFlow<FirebaseUser?> =
        repo.authState().stateIn(viewModelScope, SharingStarted.Eagerly, repo.currentUser)

    var ui by mutableStateOf(AuthUiState())
        private set

    private val usernameRegex = Regex("^[a-z0-9_]{3,15}$")

    fun clearMessages() {
        ui = ui.copy(error = null, info = null)
    }

    fun logIn(email: String, password: String) {
        val e = email.trim()
        if (e.isBlank() || password.isBlank()) return fail(R.string.err_empty)
        if (!Patterns.EMAIL_ADDRESS.matcher(e).matches()) return fail(R.string.err_email)
        run { repo.signIn(e, password) }
    }

    fun signUp(displayName: String, username: String, email: String, password: String) {
        val name = displayName.trim()
        val uname = username.trim().lowercase()
        val e = email.trim()
        if (name.isBlank() || uname.isBlank() || e.isBlank() || password.isBlank()) {
            return fail(R.string.err_empty)
        }
        if (!usernameRegex.matches(uname)) return fail(R.string.err_username_format)
        if (!Patterns.EMAIL_ADDRESS.matcher(e).matches()) return fail(R.string.err_email)
        if (password.length < 8) return fail(R.string.err_password_short)
        run { repo.signUp(name, uname, e, password) }
    }

    fun resetPassword(email: String) {
        val e = email.trim()
        if (!Patterns.EMAIL_ADDRESS.matcher(e).matches()) return fail(R.string.err_email)
        run(successInfo = R.string.reset_sent) { repo.sendPasswordReset(e) }
    }

    fun signOut() = repo.signOut()

    private fun fail(@StringRes res: Int) {
        ui = AuthUiState(error = res)
    }

    private fun run(@StringRes successInfo: Int? = null, block: suspend () -> Unit) {
        ui = AuthUiState(loading = true)
        viewModelScope.launch {
            ui = try {
                block()
                AuthUiState(info = successInfo)
            } catch (c: CancellationException) {
                throw c
            } catch (t: Throwable) {
                AuthUiState(error = mapError(t))
            }
        }
    }

    @StringRes
    private fun mapError(t: Throwable): Int = when {
        t is UsernameTakenException || t.cause is UsernameTakenException -> R.string.err_username_taken
        t is FirebaseAuthUserCollisionException -> R.string.err_email_in_use
        t is FirebaseAuthInvalidCredentialsException ||
            t is FirebaseAuthInvalidUserException -> R.string.err_invalid_credentials
        t is FirebaseNetworkException || t.cause is FirebaseNetworkException -> R.string.err_network
        t is FirebaseAuthException -> R.string.err_generic
        else -> R.string.err_generic
    }
}
