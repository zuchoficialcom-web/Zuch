package com.zuch.app.data.post

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withTimeout

/** One post as shown in the Home feed. */
data class Post(
    val id: String,
    val authorUid: String,
    val authorUsername: String,
    val authorName: String,
    val text: String,
    val likesCount: Long,
    val commentsCount: Long,
    val createdAtMillis: Long?
)

/** One comment under a post. */
data class Comment(
    val id: String,
    val authorUid: String,
    val authorUsername: String,
    val authorName: String,
    val text: String,
    val createdAtMillis: Long?
)

class PostRepository(
    private val auth: FirebaseAuth = FirebaseAuth.getInstance(),
    private val db: FirebaseFirestore = FirebaseFirestore.getInstance()
) {
    companion object {
        const val MAX_LENGTH = 500
        const val COMMENT_MAX_LENGTH = 300
        const val FEED_LIMIT = 50L
        const val COMMENTS_LIMIT = 200L
        private const val TIMEOUT_MS = 15_000L
    }

    /** Publishes a text post to the "posts" collection. Throws on failure. */
    suspend fun createPost(text: String) {
        val user = auth.currentUser ?: throw IllegalStateException("Not signed in")
        withTimeout(TIMEOUT_MS) {
            val profile = db.collection("users").document(user.uid).get().await()
            val username = profile.getString("username")
                ?: throw IllegalStateException("Profile missing")
            val displayName = profile.getString("displayName") ?: username
            db.collection("posts").add(
                mapOf(
                    "authorUid" to user.uid,
                    "authorUsername" to username,
                    "authorName" to displayName,
                    "text" to text,
                    "likesCount" to 0L,
                    "commentsCount" to 0L,
                    "createdAt" to FieldValue.serverTimestamp()
                )
            ).await()
        }
    }

    /**
     * Live feed: newest posts first. Emits a new list every time posts change.
     * The flow fails with the Firestore exception if the listener errors.
     */
    fun observePosts(limit: Long = FEED_LIMIT): Flow<List<Post>> = callbackFlow {
        val registration = db.collection("posts")
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .limit(limit)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    close(error)
                    return@addSnapshotListener
                }
                if (snapshot == null) return@addSnapshotListener
                val posts = snapshot.documents.mapNotNull { doc ->
                    val text = doc.getString("text") ?: return@mapNotNull null
                    // ESTIMATE: a post you just wrote has no server time yet; use local time.
                    val created = doc.getTimestamp(
                        "createdAt",
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    )
                    Post(
                        id = doc.id,
                        authorUid = doc.getString("authorUid").orEmpty(),
                        authorUsername = doc.getString("authorUsername").orEmpty(),
                        authorName = doc.getString("authorName")
                            ?: doc.getString("authorUsername").orEmpty(),
                        text = text,
                        likesCount = doc.getLong("likesCount") ?: 0L,
                        commentsCount = doc.getLong("commentsCount") ?: 0L,
                        createdAtMillis = created?.toDate()?.time
                    )
                }
                trySend(posts)
            }
        awaitClose { registration.remove() }
    }

    // ---------------------------------------------------------------- Likes

    /** Live "did I like this post?" flag. Emits false if there is no signed-in user. */
    fun observeLiked(postId: String): Flow<Boolean> = callbackFlow {
        val uid = auth.currentUser?.uid
        if (uid == null) {
            trySend(false)
            awaitClose { }
            return@callbackFlow
        }
        val registration = db.collection("posts").document(postId)
            .collection("likes").document(uid)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    trySend(false)
                    return@addSnapshotListener
                }
                trySend(snapshot?.exists() == true)
            }
        awaitClose { registration.remove() }
    }

    /** Likes the post if you have not liked it yet, otherwise removes your like. */
    suspend fun toggleLike(postId: String) {
        val uid = auth.currentUser?.uid ?: throw IllegalStateException("Not signed in")
        val postRef = db.collection("posts").document(postId)
        val likeRef = postRef.collection("likes").document(uid)
        withTimeout(TIMEOUT_MS) {
            db.runTransaction { tx ->
                val alreadyLiked = tx.get(likeRef).exists()
                if (alreadyLiked) {
                    tx.delete(likeRef)
                    tx.update(postRef, "likesCount", FieldValue.increment(-1))
                } else {
                    tx.set(likeRef, mapOf("createdAt" to FieldValue.serverTimestamp()))
                    tx.update(postRef, "likesCount", FieldValue.increment(1))
                }
                null
            }.await()
        }
    }

    // ------------------------------------------------------------- Comments

    /** Live comments for a post, oldest first. */
    fun observeComments(postId: String, limit: Long = COMMENTS_LIMIT): Flow<List<Comment>> =
        callbackFlow {
            val registration = db.collection("posts").document(postId)
                .collection("comments")
                .orderBy("createdAt", Query.Direction.ASCENDING)
                .limit(limit)
                .addSnapshotListener { snapshot, error ->
                    if (error != null) {
                        close(error)
                        return@addSnapshotListener
                    }
                    if (snapshot == null) return@addSnapshotListener
                    val comments = snapshot.documents.mapNotNull { doc ->
                        val text = doc.getString("text") ?: return@mapNotNull null
                        val created = doc.getTimestamp(
                            "createdAt",
                            DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                        )
                        Comment(
                            id = doc.id,
                            authorUid = doc.getString("authorUid").orEmpty(),
                            authorUsername = doc.getString("authorUsername").orEmpty(),
                            authorName = doc.getString("authorName")
                                ?: doc.getString("authorUsername").orEmpty(),
                            text = text,
                            createdAtMillis = created?.toDate()?.time
                        )
                    }
                    trySend(comments)
                }
            awaitClose { registration.remove() }
        }

    /** Adds a comment and raises the post's comment counter by one, in a single batch. */
    suspend fun addComment(postId: String, text: String) {
        val user = auth.currentUser ?: throw IllegalStateException("Not signed in")
        withTimeout(TIMEOUT_MS) {
            val profile = db.collection("users").document(user.uid).get().await()
            val username = profile.getString("username")
                ?: throw IllegalStateException("Profile missing")
            val displayName = profile.getString("displayName") ?: username

            val postRef = db.collection("posts").document(postId)
            val commentRef = postRef.collection("comments").document()
            val batch = db.batch()
            batch.set(
                commentRef,
                mapOf(
                    "authorUid" to user.uid,
                    "authorUsername" to username,
                    "authorName" to displayName,
                    "text" to text,
                    "createdAt" to FieldValue.serverTimestamp()
                )
            )
            batch.update(postRef, "commentsCount", FieldValue.increment(1))
            batch.commit().await()
        }
    }
}
