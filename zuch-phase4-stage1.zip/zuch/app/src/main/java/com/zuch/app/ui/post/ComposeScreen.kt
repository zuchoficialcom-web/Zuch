package com.zuch.app.ui.post

import android.widget.Toast
import androidx.annotation.StringRes
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.google.firebase.firestore.FirebaseFirestoreException
import com.zuch.app.R
import com.zuch.app.data.post.PostRepository
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class ComposeUiState(
    val text: String = "",
    val posting: Boolean = false,
    @StringRes val errorRes: Int? = null
)

class ComposeViewModel(
    private val repo: PostRepository = PostRepository()
) : ViewModel() {

    private val _state = MutableStateFlow(ComposeUiState())
    val state: StateFlow<ComposeUiState> = _state.asStateFlow()

    fun onTextChange(value: String) {
        if (value.length <= PostRepository.MAX_LENGTH) {
            _state.update { it.copy(text = value, errorRes = null) }
        }
    }

    fun post(onDone: () -> Unit) {
        if (_state.value.posting) return
        val clean = _state.value.text.trim()
        if (clean.isEmpty()) {
            _state.update { it.copy(errorRes = R.string.err_post_empty) }
            return
        }
        _state.update { it.copy(posting = true, errorRes = null) }
        viewModelScope.launch {
            try {
                repo.createPost(clean)
                _state.update { ComposeUiState() }
                onDone()
            } catch (e: TimeoutCancellationException) {
                fail(R.string.err_network)
            } catch (e: CancellationException) {
                throw e
            } catch (e: FirebaseFirestoreException) {
                fail(
                    when (e.code) {
                        FirebaseFirestoreException.Code.PERMISSION_DENIED -> R.string.err_post_permission
                        FirebaseFirestoreException.Code.UNAVAILABLE -> R.string.err_network
                        else -> R.string.err_generic
                    }
                )
            } catch (e: Exception) {
                fail(R.string.err_generic)
            }
        }
    }

    private fun fail(@StringRes res: Int) {
        _state.update { it.copy(posting = false, errorRes = res) }
    }
}

@Composable
fun ComposeScreen(onPosted: () -> Unit, vm: ComposeViewModel = viewModel()) {
    val state by vm.state.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val publishedMsg = stringResource(R.string.post_published)

    Column(
        Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        OutlinedTextField(
            value = state.text,
            onValueChange = vm::onTextChange,
            modifier = Modifier.fillMaxWidth().heightIn(min = 160.dp),
            placeholder = { Text(stringResource(R.string.post_hint)) },
            enabled = !state.posting,
            isError = state.errorRes != null
        )
        Row(
            Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                "${state.text.length}/${PostRepository.MAX_LENGTH}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Button(
                onClick = {
                    vm.post {
                        Toast.makeText(context, publishedMsg, Toast.LENGTH_SHORT).show()
                        onPosted()
                    }
                },
                enabled = !state.posting && state.text.isNotBlank()
            ) {
                Text(stringResource(if (state.posting) R.string.post_posting else R.string.post_button))
            }
        }
        state.errorRes?.let {
            Text(stringResource(it), color = MaterialTheme.colorScheme.error)
        }
    }
}
