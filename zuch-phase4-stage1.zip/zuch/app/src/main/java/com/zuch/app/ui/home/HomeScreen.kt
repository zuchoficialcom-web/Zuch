package com.zuch.app.ui.home

import android.widget.Toast
import androidx.annotation.StringRes
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.google.firebase.firestore.FirebaseFirestoreException
import com.zuch.app.R
import com.zuch.app.data.post.Post
import com.zuch.app.data.post.PostRepository
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.launch

sealed interface FeedState {
    data object Loading : FeedState
    data class Error(@StringRes val messageRes: Int) : FeedState
    data class Success(val posts: List<Post>) : FeedState
}

/** Maps a failure to a short, friendly message. Shared by Home and Comments. */
internal fun firestoreErrorRes(e: Throwable): Int = when {
    e is TimeoutCancellationException -> R.string.err_network
    e is FirebaseFirestoreException -> when (e.code) {
        FirebaseFirestoreException.Code.PERMISSION_DENIED -> R.string.err_post_permission
        FirebaseFirestoreException.Code.UNAVAILABLE -> R.string.err_network
        else -> R.string.err_generic
    }
    else -> R.string.err_generic
}

class HomeViewModel(
    private val repo: PostRepository = PostRepository()
) : ViewModel() {

    private val _state = MutableStateFlow<FeedState>(FeedState.Loading)
    val state: StateFlow<FeedState> = _state.asStateFlow()

    // One-time messages (for example "could not like") shown as a toast.
    private val _messages = MutableSharedFlow<Int>(extraBufferCapacity = 4)
    val messages: SharedFlow<Int> = _messages.asSharedFlow()

    private var job: Job? = null

    init {
        load()
    }

    fun load() {
        job?.cancel()
        _state.value = FeedState.Loading
        job = viewModelScope.launch {
            repo.observePosts()
                .catch { e ->
                    if (e is CancellationException) throw e
                    _state.value = FeedState.Error(firestoreErrorRes(e))
                }
                .collect { posts -> _state.value = FeedState.Success(posts) }
        }
    }

    fun likedFlow(postId: String): Flow<Boolean> = repo.observeLiked(postId)

    fun toggleLike(postId: String) {
        viewModelScope.launch {
            try {
                repo.toggleLike(postId)
            } catch (e: TimeoutCancellationException) {
                _messages.tryEmit(R.string.err_network)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _messages.tryEmit(
                    if (e is FirebaseFirestoreException) firestoreErrorRes(e) else R.string.err_like
                )
            }
        }
    }
}

@Composable
fun HomeScreen(
    onOpenComments: (String) -> Unit,
    vm: HomeViewModel = viewModel()
) {
    val state by vm.state.collectAsStateWithLifecycle()
    val context = LocalContext.current

    LaunchedEffect(vm) {
        vm.messages.collect { res ->
            Toast.makeText(context, context.getString(res), Toast.LENGTH_SHORT).show()
        }
    }

    when (val s = state) {
        is FeedState.Loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator()
        }

        is FeedState.Error -> Column(
            Modifier.fillMaxSize().padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                stringResource(s.messageRes),
                color = MaterialTheme.colorScheme.error,
                modifier = Modifier.padding(bottom = 12.dp)
            )
            Button(onClick = vm::load) { Text(stringResource(R.string.feed_retry)) }
        }

        is FeedState.Success ->
            if (s.posts.isEmpty()) {
                Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                    Text(
                        stringResource(R.string.feed_empty),
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                LazyColumn(
                    Modifier.fillMaxSize(),
                    // Extra bottom space so the "+" button never hides the last post.
                    contentPadding = PaddingValues(bottom = 96.dp)
                ) {
                    items(s.posts, key = { it.id }) { post ->
                        PostItem(
                            post = post,
                            likedFlow = remember(post.id) { vm.likedFlow(post.id) },
                            onLike = { vm.toggleLike(post.id) },
                            onComments = { onOpenComments(post.id) }
                        )
                        HorizontalDivider(color = MaterialTheme.colorScheme.outline)
                    }
                }
            }
    }
}

@Composable
private fun PostItem(
    post: Post,
    likedFlow: Flow<Boolean>,
    onLike: () -> Unit,
    onComments: () -> Unit
) {
    val liked by likedFlow.collectAsStateWithLifecycle(initialValue = false)

    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp)) {
        AuthorLine(post.authorName, post.authorUsername, post.createdAtMillis)
        Text(post.text, modifier = Modifier.padding(top = 6.dp))
        Row(
            Modifier.padding(top = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onLike) {
                Icon(
                    imageVector = if (liked) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
                    contentDescription = stringResource(R.string.cd_like),
                    tint = if (liked) MaterialTheme.colorScheme.primary
                    else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Text(
                post.likesCount.toString(),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(end = 16.dp)
            )
            IconButton(onClick = onComments) {
                Icon(
                    imageVector = Icons.Outlined.ChatBubbleOutline,
                    contentDescription = stringResource(R.string.cd_comments),
                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Text(
                post.commentsCount.toString(),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

/** "Name  @username  ·  5m" header line, used for posts and comments. */
@Composable
internal fun AuthorLine(name: String, username: String, createdAtMillis: Long?) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(
            name,
            fontWeight = FontWeight.Bold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f, fill = false)
        )
        Text(
            "  @$username",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f, fill = false)
        )
        Text(
            "  ·  " + timeAgo(createdAtMillis),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 1
        )
    }
}

@Composable
internal fun timeAgo(millis: Long?): String {
    if (millis == null) return stringResource(R.string.time_now)
    val minutes = ((System.currentTimeMillis() - millis) / 60_000L).coerceAtLeast(0L)
    return when {
        minutes < 1L -> stringResource(R.string.time_now)
        minutes < 60L -> stringResource(R.string.time_minutes, minutes)
        minutes < 24L * 60L -> stringResource(R.string.time_hours, minutes / 60L)
        else -> stringResource(R.string.time_days, minutes / (24L * 60L))
    }
}
