package com.zuch.app.data.auth

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.UserProfileChangeRequest
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await

class UsernameTakenException : Exception("Username taken")

class AuthRepository(
    private val auth: FirebaseAuth = FirebaseAuth.getInstance(),
    private val db: FirebaseFirestore = FirebaseFirestore.getInstance()
) {
    val currentUser: FirebaseUser? get() = auth.currentUser

    fun authState(): Flow<FirebaseUser?> = callbackFlow {
        val listener = FirebaseAuth.AuthStateListener { trySend(it.currentUser) }
        auth.addAuthStateListener(listener)
        awaitClose { auth.removeAuthStateListener(listener) }
    }

    suspend fun signIn(email: String, password: String) {
        auth.signInWithEmailAndPassword(email, password).await()
    }

    suspend fun isUsernameAvailable(username: String): Boolean =
        !db.collection("usernames").document(username).get().await().exists()

    /**
     * Creates the auth account, then atomically reserves the username and writes
     * the public profile. If reservation fails, the new auth account is removed.
     */
    suspend fun signUp(displayName: String, username: String, email: String, password: String) {
        if (!isUsernameAvailable(username)) throw UsernameTakenException()

        val user = auth.createUserWithEmailAndPassword(email, password).await().user
            ?: throw IllegalStateException("No user returned")
        try {
            val nameRef = db.collection("usernames").document(username)
            val userRef = db.collection("users").document(user.uid)
            db.runTransaction { tx ->
                if (tx.get(nameRef).exists()) throw UsernameTakenException()
                tx.set(nameRef, mapOf("uid" to user.uid))
                tx.set(
                    userRef,
                    mapOf(
                        "uid" to user.uid,
                        "username" to username,
                        "displayName" to displayName,
                        "bio" to "",
                        "photoUrl" to "",
                        "language" to "en",
                        "followersCount" to 0L,
                        "followingCount" to 0L,
                        "postsCount" to 0L,
                        "createdAt" to FieldValue.serverTimestamp()
                    )
                )
                null
            }.await()
            user.updateProfile(
                UserProfileChangeRequest.Builder().setDisplayName(displayName).build()
            ).await()
        } catch (e: Exception) {
            runCatching { user.delete().await() }
            throw e
        }
    }

    suspend fun sendPasswordReset(email: String) {
        auth.sendPasswordResetEmail(email).await()
    }

    fun signOut() = auth.signOut()
}
