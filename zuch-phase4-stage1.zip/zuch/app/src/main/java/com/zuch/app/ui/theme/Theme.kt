package com.zuch.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import com.zuch.app.data.ThemeMode

val Saffron = Color(0xFFE69A25)
val SaffronDeep = Color(0xFFC77712)
val Cream = Color(0xFFFFF8EC)
val Ink = Color(0xFF29241D)

private val LightColors = lightColorScheme(
    primary = Saffron,
    onPrimary = Ink,
    primaryContainer = Color(0xFFFBE3BC),
    onPrimaryContainer = Ink,
    secondary = SaffronDeep,
    onSecondary = Color.White,
    background = Cream,
    onBackground = Ink,
    surface = Cream,
    onSurface = Ink,
    surfaceVariant = Color(0xFFF3E6CF),
    onSurfaceVariant = Color(0xFF5C5245),
    outline = Color(0xFFD9C9AC)
)

private val DarkColors = darkColorScheme(
    primary = Saffron,
    onPrimary = Ink,
    primaryContainer = Color(0xFF4A3410),
    onPrimaryContainer = Color(0xFFFBE3BC),
    secondary = Color(0xFFE8A74A),
    onSecondary = Ink,
    background = Color(0xFF17130E),
    onBackground = Color(0xFFF6ECDD),
    surface = Color(0xFF17130E),
    onSurface = Color(0xFFF6ECDD),
    surfaceVariant = Color(0xFF2A231A),
    onSurfaceVariant = Color(0xFFCDBFA9),
    outline = Color(0xFF4A4034)
)

@Composable
fun ZuchTheme(mode: ThemeMode, content: @Composable () -> Unit) {
    val dark = when (mode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }
    MaterialTheme(colorScheme = if (dark) DarkColors else LightColors, content = content)
}
