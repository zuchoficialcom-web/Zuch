package com.zuch.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.zuch.app.data.SettingsStore
import com.zuch.app.ui.auth.AuthScreen
import com.zuch.app.ui.auth.AuthViewModel
import com.zuch.app.ui.main.MainScaffold
import com.zuch.app.ui.theme.ZuchTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val mode by SettingsStore.theme.collectAsStateWithLifecycle()
            ZuchTheme(mode) {
                Surface(color = MaterialTheme.colorScheme.background) { ZuchRoot() }
            }
        }
    }
}

@Composable
private fun ZuchRoot() {
    val vm: AuthViewModel = viewModel()
    val user by vm.user.collectAsStateWithLifecycle()
    val current = user
    if (current == null) {
        AuthScreen(vm)
    } else {
        MainScaffold(
            userLabel = current.displayName?.takeIf { it.isNotBlank() } ?: current.email.orEmpty(),
            email = current.email.orEmpty(),
            onSignOut = vm::signOut
        )
    }
}
