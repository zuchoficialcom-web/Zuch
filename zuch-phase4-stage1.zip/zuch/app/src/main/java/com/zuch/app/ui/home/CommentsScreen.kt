package com.zuch.app.ui.home

import androidx.annotation.StringRes
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.zuch.app.R
import com.zuch.app.data.post.Comment
import com.zuch.app.data.post.PostRepository
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class CommentsUiState(
    val comments: List<Comment> = emptyList(),
    val loading: Boolean = true,
    val text: String = "",
    val posting: Boolean = false,
    @StringRes val errorRes: Int? = null
)

/** The post id arrives through the navigation route ("comments/{postId}"). */
class CommentsViewModel(savedStateHandle: SavedStateHandle) : ViewModel() {

    private val repo = PostRepository()
    private val postId: String = savedStateHandle.get<String>("postId").orEmpty()

    private val _state = MutableStateFlow(CommentsUiState())
    val state: StateFlow<CommentsUiState> = _state.asStateFlow()

    init {
        viewModelScope.launch {
            repo.observeComments(postId)
                .catch { e ->
                    if (e is CancellationException) throw e
                    _state.update { it.copy(loading = false, errorRes = firestoreErrorRes(e)) }
                }
                .collect { list ->
                    _state.update { it.copy(comments = list, loading = false) }
                }
        }
    }

    fun onTextChange(value: String) {
        if (value.length <= PostRepository.COMMENT_MAX_LENGTH) {
            _state.update { it.copy(text = value, errorRes = null) }
        }
    }

    fun send() {
        val current = _state.value
        if (current.posting) return
        val clean = current.text.trim()
        if (clean.isEmpty()) return
        _state.update { it.copy(posting = true, errorRes = null) }
        viewModelScope.launch {
            try {
                repo.addComment(postId, clean)
                _state.update { it.copy(text = "", posting = false) }
            } catch (e: TimeoutCancellationException) {
                _state.update { it.copy(posting = false, errorRes = R.string.err_network) }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _state.update { it.copy(posting = false, errorRes = firestoreErrorRes(e)) }
            }
        }
    }
}

@Composable
fun CommentsScreen(vm: CommentsViewModel = viewModel()) {
    val state by vm.state.collectAsStateWithLifecycle()

    Column(Modifier.fillMaxSize().imePadding()) {
        Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
            when {
                state.loading -> CircularProgressIndicator()
                state.comments.isEmpty() -> Text(
                    stringResource(R.string.comments_empty),
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(24.dp)
                )
                else -> LazyColumn(Modifier.fillMaxSize()) {
                    items(state.comments, key = { it.id }) { c ->
                        Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp)) {
                            AuthorLine(c.authorName, c.authorUsername, c.createdAtMillis)
                            Text(c.text, modifier = Modifier.padding(top = 4.dp))
                        }
                        HorizontalDivider(color = MaterialTheme.colorScheme.outline)
                    }
                }
            }
        }

        state.errorRes?.let {
            Text(
                stringResource(it),
                color = MaterialTheme.colorScheme.error,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
            )
        }

        HorizontalDivider(color = MaterialTheme.colorScheme.outline)
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = state.text,
                onValueChange = vm::onTextChange,
                modifier = Modifier.weight(1f),
                placeholder = { Text(stringResource(R.string.comment_hint)) },
                enabled = !state.posting,
                maxLines = 4
            )
            IconButton(
                onClick = vm::send,
                enabled = !state.posting && state.text.isNotBlank()
            ) {
                Icon(Icons.AutoMirrored.Filled.Send, stringResource(R.string.comment_send))
            }
        }
    }
}
