package com.zuch.app.ui.main

import androidx.annotation.StringRes
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.Logout
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Mail
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.MailOutline
import androidx.compose.material.icons.outlined.NotificationsNone
import androidx.compose.material.icons.outlined.PersonOutline
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.zuch.app.R
import com.zuch.app.ui.post.ComposeScreen
import kotlinx.coroutines.launch

private data class Dest(
    val route: String,
    @StringRes val label: Int,
    val icon: ImageVector,
    val outlined: ImageVector
)

private val Home = Dest("home", R.string.nav_home, Icons.Filled.Home, Icons.Outlined.Home)
private val Explore = Dest("explore", R.string.nav_explore, Icons.Filled.Search, Icons.Outlined.Search)
private val Notifs = Dest("notifications", R.string.nav_notifications, Icons.Filled.Notifications, Icons.Outlined.NotificationsNone)
private val Messages = Dest("messages", R.string.nav_messages, Icons.Filled.Mail, Icons.Outlined.MailOutline)
private val Bookmarks = Dest("bookmarks", R.string.nav_bookmarks, Icons.Filled.Bookmark, Icons.Outlined.BookmarkBorder)
private val Profile = Dest("profile", R.string.nav_profile, Icons.Filled.Person, Icons.Outlined.PersonOutline)
private val Settings = Dest("settings", R.string.nav_settings, Icons.Filled.Settings, Icons.Outlined.Settings)

private val bottomDests = listOf(Home, Explore, Notifs, Messages)
private val drawerDests = listOf(Profile, Bookmarks, Settings)
private const val ROUTE_COMPOSE = "compose"

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScaffold(userLabel: String, email: String, onSignOut: () -> Unit) {
    val nav = rememberNavController()
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val backStack by nav.currentBackStackEntryAsState()
    val route = backStack?.destination?.route ?: Home.route

    val titleRes = (bottomDests + drawerDests).firstOrNull { it.route == route }?.label
        ?: R.string.create_post
    val showBottomBar = bottomDests.any { it.route == route }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet {
                Column(Modifier.padding(20.dp)) {
                    Text(
                        stringResource(R.string.app_name),
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.ExtraBold,
                        color = MaterialTheme.colorScheme.secondary
                    )
                    Text(userLabel, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 12.dp))
                    if (email.isNotBlank() && email != userLabel) {
                        Text(email, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                drawerDests.forEach { d ->
                    NavigationDrawerItem(
                        label = { Text(stringResource(d.label)) },
                        icon = { Icon(d.outlined, null) },
                        selected = route == d.route,
                        onClick = {
                            scope.launch { drawerState.close() }
                            nav.goTo(d.route)
                        },
                        modifier = Modifier.padding(horizontal = 12.dp)
                    )
                }
                NavigationDrawerItem(
                    label = { Text(stringResource(R.string.sign_out)) },
                    icon = { Icon(Icons.AutoMirrored.Outlined.Logout, null) },
                    selected = false,
                    onClick = { scope.launch { drawerState.close() }; onSignOut() },
                    modifier = Modifier.padding(horizontal = 12.dp)
                )
            }
        }
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Text(
                            stringResource(if (route == Home.route) R.string.app_name else titleRes),
                            fontWeight = FontWeight.Bold,
                            color = if (route == Home.route) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.onSurface
                        )
                    },
                    navigationIcon = {
                        IconButton(onClick = { scope.launch { drawerState.open() } }) {
                            Icon(Icons.Filled.Menu, stringResource(R.string.open_menu))
                        }
                    }
                )
            },
            bottomBar = {
                if (showBottomBar) {
                    NavigationBar {
                        bottomDests.forEach { d ->
                            val selected = route == d.route
                            NavigationBarItem(
                                selected = selected,
                                onClick = { nav.goTo(d.route) },
                                icon = { Icon(if (selected) d.icon else d.outlined, stringResource(d.label)) },
                                alwaysShowLabel = false
                            )
                        }
                    }
                }
            },
            floatingActionButton = {
                if (showBottomBar) {
                    FloatingActionButton(
                        onClick = { nav.navigate(ROUTE_COMPOSE) { launchSingleTop = true } },
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = MaterialTheme.colorScheme.onPrimary
                    ) { Icon(Icons.Filled.Add, stringResource(R.string.create_post)) }
                }
            }
        ) { padding ->
            NavHost(nav, startDestination = Home.route, modifier = Modifier.padding(padding)) {
                composable(Home.route) { PhasePlaceholder(R.string.nav_home, 4) }
                composable(Explore.route) { PhasePlaceholder(R.string.nav_explore, 5) }
                composable(Notifs.route) { PhasePlaceholder(R.string.nav_notifications, 6) }
                composable(Messages.route) { PhasePlaceholder(R.string.nav_messages, 6) }
                composable(Bookmarks.route) { PhasePlaceholder(R.string.nav_bookmarks, 7) }
                composable(Profile.route) { PhasePlaceholder(R.string.nav_profile, 2) }
                composable(Settings.route) { SettingsScreen(email, onSignOut) }
                composable(ROUTE_COMPOSE) { ComposeScreen(onPosted = { nav.popBackStack() }) }
            }
        }
    }
}

private fun NavHostController.goTo(route: String) {
    navigate(route) {
        popUpTo(graph.findStartDestination().id) { saveState = true }
        launchSingleTop = true
        restoreState = true
    }
}
