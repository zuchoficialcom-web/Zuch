package com.zuch.app.data.post

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withTimeout

class PostRepository(
    private val auth: FirebaseAuth = FirebaseAuth.getInstance(),
    private val db: FirebaseFirestore = FirebaseFirestore.getInstance()
) {
    companion object {
        const val MAX_LENGTH = 500
        private const val TIMEOUT_MS = 15_000L
    }

    /** Publishes a text post to the "posts" collection. Throws on failure. */
    suspend fun createPost(text: String) {
        val user = auth.currentUser ?: throw IllegalStateException("Not signed in")
        withTimeout(TIMEOUT_MS) {
            val profile = db.collection("users").document(user.uid).get().await()
            val username = profile.getString("username")
                ?: throw IllegalStateException("Profile missing")
            val displayName = profile.getString("displayName") ?: username
            db.collection("posts").add(
                mapOf(
                    "authorUid" to user.uid,
                    "authorUsername" to username,
                    "authorName" to displayName,
                    "text" to text,
                    "likesCount" to 0L,
                    "commentsCount" to 0L,
                    "createdAt" to FieldValue.serverTimestamp()
                )
            ).await()
        }
    }
}
